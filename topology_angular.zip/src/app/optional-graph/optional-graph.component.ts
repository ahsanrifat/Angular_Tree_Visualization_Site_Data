import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optional-graph',
  templateUrl: './optional-graph.component.html',
  styleUrls: ['./optional-graph.component.css']
})
export class OptionalGraphComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
