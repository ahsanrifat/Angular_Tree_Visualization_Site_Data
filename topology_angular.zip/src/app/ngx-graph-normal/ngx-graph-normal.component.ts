import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngx-graph-normal',
  templateUrl: './ngx-graph-normal.component.html',
  styleUrls: ['./ngx-graph-normal.component.css']
})
export class NgxGraphNormalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
