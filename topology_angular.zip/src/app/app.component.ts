// import SpriteText from 'three-spritetext';
import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Graph Explorer';
  constructor() {}
  public ngOnInit(): void {}
}
